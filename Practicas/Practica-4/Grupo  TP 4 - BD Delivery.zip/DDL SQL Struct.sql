CREATE TABLE dw_delivery.fact_venta
(
  venta_id INT
, fecha_hora_id DATETIME
, proveedor_id BIGINT
, cliente_id INT
, repartidor_id INT
, zona_id INT
, pago_id INT
, tipo_proveedor_hizo VARCHAR(100)
, monto_origen DECIMAL(22)
)
;

CREATE TABLE dw_delivery.dim_cliente
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_cliente INT
, nombres VARCHAR(100)
, apellidos VARCHAR(100)
, sexo CHAR(1)
, domicilio_id INT
, fecha_alta DATETIME
, fecha_baja DATETIME
)
;CREATE INDEX idx_dim_cliente_lookup ON dw_delivery.dim_cliente(pk_cliente)
;
CREATE INDEX idx_dim_cliente_tk ON dw_delivery.dim_cliente(id)
;

CREATE TABLE dw_delivery.dim_tiempo
(
  id_tiempo BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_tiempo DATETIME
, fecha DATETIME
, fecha_dias DATETIME
)
;CREATE INDEX idx_dim_tiempo_lookup ON dw_delivery.dim_tiempo(pk_tiempo)
;
CREATE INDEX idx_dim_tiempo_tk ON dw_delivery.dim_tiempo(id_tiempo)
;

CREATE TABLE dw_delivery.dim_repartidor
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_repartidor INT
, nombres VARCHAR(100)
, apellidos VARCHAR(100)
, sexo CHAR(1)
, fecha_alta DATETIME
, fecha_baja DATETIME
)
;CREATE INDEX idx_dim_repartidor_lookup ON dw_delivery.dim_repartidor(pk_repartidor)
;
CREATE INDEX idx_dim_repartidor_tk ON dw_delivery.dim_repartidor(id)
;


CREATE TABLE dw_delivery.dim_pago
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_pago INT
, venta_id INT
, tipo_id INT
, monto DOUBLE
)
;CREATE INDEX idx_dim_pago_lookup ON dw_delivery.dim_pago(pk_pago)
;
CREATE INDEX idx_dim_pago_tk ON dw_delivery.dim_pago(id)
;

CREATE TABLE dw_delivery.dim_proveedor
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_proveedor INT
, nombre VARCHAR(100)
, tipo_proveedor VARCHAR(100)
, fecha_alta_actividad DATETIME
, fecha_baja_actividad DATETIME
, domicilio_id INT
)
;CREATE INDEX idx_dim_proveedor_lookup ON dw_delivery.dim_proveedor(pk_proveedor)
;
CREATE INDEX idx_dim_proveedor_tk ON dw_delivery.dim_proveedor(id)
;

CREATE TABLE dw_delivery.dim_zona
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_zona INT
, nombre VARCHAR(100)
)
;CREATE INDEX idx_dim_zona_lookup ON dw_delivery.dim_zona(pk_zona)
;
CREATE INDEX idx_dim_zona_tk ON dw_delivery.dim_zona(id)
;

CREATE TABLE dw_delivery.dim_domicilio
(
  id BIGINT NOT NULL PRIMARY KEY
, version INT
, date_from DATETIME
, date_to DATETIME
, pk_domicilio INT
, zona_id INT
, calle VARCHAR(100)
, numero INT
, calle_entre_1 VARCHAR(100)
, calle_entre_2 VARCHAR(100)
, piso VARCHAR(100)
, departamento VARCHAR(100)
)
;CREATE INDEX idx_dim_domicilio_lookup ON dw_delivery.dim_domicilio(pk_domicilio)
;
CREATE INDEX idx_dim_domicilio_tk ON dw_delivery.dim_domicilio(id)
;
